#include <stdint.h>
#include "tm4c123gh6pm.h"

volatile uint32_t count=0;
void InterruptPortF_Init(void);
void time_delay(uint8_t t);

int main(void)
{
		count=0;
  InterruptPortF_Init();  
	count=0;
  while(1)
	{
		if(count==0)
		{
			GPIO_PORTF_DATA_R = 0x00;
			GPIO_PORTD_DATA_R = 0x00;
			count=1;
		}
		if(count==1)
		{
			int i=0;
			count=2;
			for(i=0; i<2; i++)
			{
				GPIO_PORTF_DATA_R = 0x04;
				time_delay(4);
				GPIO_PORTF_DATA_R = 0x00;
				time_delay(4);				
			}

		}
		if(count==2)
		{
			int k=0;
			for(k=0; k<5; k++)
			{
				GPIO_PORTF_DATA_R = 0x08;
				time_delay(2);
				GPIO_PORTF_DATA_R = 0x00;
				time_delay(2);	
			}
			count=1;
		}
		if(count==3)
		{
			int i=0;
			for(i=0; i<2; i++)
			{
				GPIO_PORTF_DATA_R = 0x02;
				time_delay(2);
				GPIO_PORTF_DATA_R = 0x00;
				time_delay(2);

			}
			count=4;
		}
		if (count==4)
		{
			int i=0;
			for(i=0; i<2; i++)
			{
				GPIO_PORTF_DATA_R = 0x02;
				time_delay(4);
				GPIO_PORTF_DATA_R = 0x00;
				time_delay(4);
			}
			count=5;
		}
		if (count==5)
		{
				int j=0;
				while(j<5) //executa a a��o 5 vezes
				{
					GPIO_PORTD_DATA_R=0x04; //Liga o 4 bit da porta D, ou seja, PD3
					
					GPIO_PORTF_DATA_R = 0x08; //LED verde
					time_delay(4);
					GPIO_PORTF_DATA_R = 0x00;  //LEDS APAGADOS	
					time_delay(4);
					GPIO_PORTF_DATA_R = 0x04;  //LED azul
					time_delay(4);
					GPIO_PORTF_DATA_R = 0x00; //LEDS APAGADOS	 
					time_delay(4);
					GPIO_PORTF_DATA_R = 0x02; //LED vermelho  
					time_delay(4);
					GPIO_PORTF_DATA_R = 0x00;  //LEDS APAGADOS	
					time_delay(4);
					j=j+1;
			}
				count=0;
		}
		
	}
}


void InterruptPortF_Init(void)
{                          
  SYSCTL_RCGCGPIO_R |= 0xFF; // (a) clock para F E D
  count = 0;             // INICIALIZA CONTADOR
  GPIO_PORTF_LOCK_R = 0x4C4F434B;   
  GPIO_PORTF_CR_R = 0x1F;           // allow changes to PF4-0
  GPIO_PORTF_DIR_R |=  0x0E;    // output on PF3,2,1 
  GPIO_PORTF_DIR_R &= ~0x11;    // (c) make PF4,0 in (built-in button)
  GPIO_PORTF_AFSEL_R &= ~0x1F;  //     disable alt funct on PF4,0
  GPIO_PORTF_DEN_R |= 0x1F;     //     enable digital I/O on PF4   
  GPIO_PORTF_PCTL_R &= ~0x000FFFFF; // configure PF4 as GPIO
  GPIO_PORTF_AMSEL_R = 0;       //     disable analog functionality on PF
  GPIO_PORTF_PUR_R |= 0x11;     //     enable weak pull-up on PF4
  GPIO_PORTF_IS_R &= ~0x01;     // (d) PF4 is edge-sensitive
  GPIO_PORTF_IBE_R &= ~0x01;    //     PF4 is not both edges
  GPIO_PORTF_IEV_R &= ~0x01;    //     PF4 falling edge event
  GPIO_PORTF_ICR_R = 0x01;      // (e) clear flag4
  GPIO_PORTF_IM_R |= 0x01;      // (f) arm interrupt on PF4 *** No IME bit as mentioned in Book ***
  NVIC_PRI7_R = (NVIC_PRI7_R&0xFF00FFFF)|0x00A00000; // (g) priority 5
  NVIC_EN0_R = 0x40000000;      // (h) enable interrupt 30 in NVIC		volatile unsigned long delay;
  GPIO_PORTD_LOCK_R = 0x4C4F434B;   //Desbloqueia PortD  
  GPIO_PORTD_CR_R = 0x1F;           //Permite mudan�as do portD   
  GPIO_PORTD_AMSEL_R = 0x00;        //Desativa fun��o anal�gica do uC
  GPIO_PORTD_PCTL_R &= ~0x0000FFFF;   //Limpa o bit PCTL  
  GPIO_PORTD_DIR_R |= 0x0E;          // Ativa sa�da PD3
  GPIO_PORTD_AFSEL_R &= ~0x1F;        // Sem fun��o alternativa    
  GPIO_PORTD_DEN_R |= 0x1F;          // Ativa portas digitais  
}



void GPIOPortF_Handler(void)
{
  GPIO_PORTF_ICR_R = 0x01;   
  count=3;

}
void time_delay(uint8_t t)
{
	unsigned long volatile time;
	time = t*(727240*200/91); //Tempo de 0.1 (esse valor resulta em 1.6 M, como o programa executar� as linhas de 
	//c�digo 1.6.10^6 vezes, causar� um atraso na visualiza��o da sa�da de 0.1 s considerando o clock de 16MHz para
	//esse ucontrolador
	while(time>0)
	{
		time--; //decrementa 1.6.10^6 vezes para provocar atraso
	}
	
}